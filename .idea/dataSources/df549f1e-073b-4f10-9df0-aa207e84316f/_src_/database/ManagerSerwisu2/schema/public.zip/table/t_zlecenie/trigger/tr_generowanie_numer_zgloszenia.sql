CREATE TRIGGER tr_generowanie_numer_zgloszenia
AFTER INSERT ON public.t_zlecenie
FOR EACH ROW EXECUTE PROCEDURE f_generowanie_numer_zgloszenia()